library(rfcdmin)
data(VRCmin)

## flow cyt data 

fsc <- as.vector(as(unst.DRT@data[,1], "matrix"))
ssc <- as.vector(as(unst.DRT@data[,2], "matrix"))
cd8 <- as.vector(as(unst.DRT@data[,3], "matrix"))
ifn <- as.vector(as(unst.DRT@data[,4], "matrix"))
cd4 <- as.vector(as(unst.DRT@data[,5], "matrix"))
cd3 <- as.vector(as(unst.DRT@data[,7], "matrix"))

## length=194629
flow <- as.data.frame(cbind(fsc, ssc, cd3, cd4))
names(flow) <- c("FSC", "SSC", "CD3", "CD4")

## filter out debris - values same as Haarland PPT presentation
filter.gate <- flow$FSC>=200 & flow$FSC<=800 & flow$SSC>=0 & flow$SSC<=800
flow <- flow[filter.gate,c(1,2,4)]
## length=175098

## CD4+ lymphocyte gate -- FSC, SSC gate from rflowcyt ## red points in Fig 1
lymph.gate <- flow$FSC>=300 & flow$FSC<=650 & flow$SSC>=300 & flow$SSC<=500 & flow$CD4 > 450
flow.lymph <- flow[lymph.gate,1:3]

